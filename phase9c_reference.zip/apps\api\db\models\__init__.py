"""Import all models so Alembic autogeneration sees the complete schema."""

from apps.api.db.models.analysis_job import AnalysisJob
from apps.api.db.models.audit import AuditEvent
from apps.api.db.models.claim import AtomicClaim, Claim
from apps.api.db.models.document import Document
from apps.api.db.models.document_version import DocumentVersion
from apps.api.db.models.evidence import Evidence
from apps.api.db.models.evidence_provenance import EvidenceProvenance
from apps.api.db.models.model_run import ModelRun
from apps.api.db.models.prediction import Prediction
from apps.api.db.models.retrieval_observation import RetrievalObservation
from apps.api.db.models.source import Source
from apps.api.db.models.verification import VerificationResult

__all__ = [
    "AnalysisJob",
    "AtomicClaim",
    "AuditEvent",
    "Claim",
    "Document",
    "DocumentVersion",
    "Evidence",
    "EvidenceProvenance",
    "ModelRun",
    "Prediction",
    "RetrievalObservation",
    "Source",
    "VerificationResult",
]
